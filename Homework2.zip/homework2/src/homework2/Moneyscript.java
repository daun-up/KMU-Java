package homework2;

import java.util.Scanner;

public class Moneyscript {
	public static void main(String args[]) {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("���� �� :");
		int M;
		M = scan.nextInt();
		System.out.print("��ǰ ���� :");
		int P;
		P = scan.nextInt();
		System.out.println("�ΰ��� :"+(int)(P*0.1));
		System.out.println("�ܵ� :"+ (M-P));
		
	}

}
